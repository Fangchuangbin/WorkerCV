// This file is created by egg-ts-helper@1.25.8
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportCollect = require('../../../app/controller/collect');
import ExportCommon = require('../../../app/controller/common');
import ExportIndex = require('../../../app/controller/index');
import ExportResume = require('../../../app/controller/resume');

declare module 'egg' {
  interface IController {
    collect: ExportCollect;
    common: ExportCommon;
    index: ExportIndex;
    resume: ExportResume;
  }
}
